#include<stdio.h>
int main()
{
    int a,b,c=180;

    printf("enter the value of a=");
    scanf("%d",&a);
    printf("enter the value of b=");
    scanf("%d",&b);

    c=c-a-b;

    printf("he third angle of triangle to two number=%d",c);

}