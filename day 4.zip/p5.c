#include<stdio.h>
int main()
{
    int x,y;

    printf("enter value of x=");
    scanf("%d",&x);
    printf("enter value of y=");
    scanf("%d",&y);

    printf("find the formula's answer:%d",(x+y)^3);

    return 0;

}