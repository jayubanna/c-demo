#include<stdio.h>
int main()
{
    int x,y,z;

    printf("enter value of x=");
    scanf("%d",&x);
    printf("enter value of y=");
    scanf("%d",&y);
      printf("enter value of z=");
    scanf("%d",&z);

    printf("find the formula's answer:%d",(x+y+z)^2);

    return 0;

}