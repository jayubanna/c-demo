#include<stdio.h>
int main()
{
   int opt;

    printf("enter the days name opt=");
    scanf("%d",&opt);

    if(opt==1)
    {
        printf("this is january");
    }
   else if(opt==2)
    {
        printf("this is february");
    }
   else if(opt==3)
    {
        printf("this is march");
    }
    else if(opt==4)
    {
        printf("this is april");
    }
     else if(opt==5)
    {
        printf("this is may");
    }
      else if(opt==6)
    {
        printf("this is june");
    }
      else if(opt==7)
    {
        printf("this is july");
    }
      else if(opt==8)
    {
        printf("this is august");
    }
      else if(opt==9)
    {
        printf("this is september");
    }
      else if(opt==10)
    {
        printf("this is october");
    }
      else if(opt==11)
    {
        printf("this is november");
    }
      else if(opt==12)
    {
        printf("this is december");
    }
    else{
        printf("wrong input by user **__--__**");
    }

}