#include<stdio.h>
int main()
{
    printf("Addition of 12 and 6 is 18\n");

    int a=12,b=6;
    int c=a+b;
    
    printf("%d+%d=%d\n\n",a,b,c);


    printf("Subtraction of 12 and 6 is 6\n"); 

    int i=12,j=6;
    int k=i-j;
    
    printf("%d-%d=%d\n\n",i,j,k);


    printf("Multiplication of 12 and 6 is 72\n"); 

    int d=12,e=6;
    int f=i*j;
    
    printf("%d*%d=%d\n\n",d,e,f);

    
    printf("Division of 12 and 6 is 2\n"); 

    int r=12,s=6;
    int t=r/s;
    
    printf("%d/%d=%d\n\n",r,s,t);

     printf("Modulo of 12 and 6 \n\n"); 

    int u=12,v=6;
    int w=u%v;
    
    printf("Modulo of 12 and 6 is=%d",w);
   
    
  
    
    
  

    return 0;

}