#include<stdio.h>
int main()
{
    int i=16;

    printf("%d*1=%d\n",i,i*1);
    printf("%d*2=%d\n",i,i*2);
    printf("%d*3=%d\n",i,i*3);
    printf("%d*4=%d\n",i,i*4);
    printf("%d*5=%d\n",i,i*5);
    printf("%d*6=%d\n",i,i*6);
    printf("%d*7=%d\n",i,i*7);
    printf("%d*8=%d\n",i,i*8);
    printf("%d*9=%d\n",i,i*9);
    printf("%d*10=%d",i,i*10);

    return 0;
}