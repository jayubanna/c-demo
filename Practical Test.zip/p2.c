#include<stdio.h>
int main()
{
    int a,fact=1,*ptr;

    printf("enter the of the number:");
    scanf("%d",&a);

    for (int i = 1; i <=a; i++)
    {
        fact = fact * i;
        *ptr=fact;
    }

    printf("this is factorial number:%d",*ptr);
    
    return 0;
}