#include <stdio.h>
void wap(int a,int b)
{
    int x,y;

    printf("enter strat number:");
    scanf("%d",&x);
    printf("enter end number:");
    scanf("%d",&y);

    for (int i = x; i < y; i++)
    {
        if (i%3==0 && i%5==0)
        {
            printf("%d ",i);
        }
    }
}
int main(int c,int d)
{
    wap(c,d);
    return 0;
}