#include <stdio.h>
int main()
{
    FILE *file = fopen("leap.txt", "w");

    int a, b;

    printf("enter years strat:");
    scanf("%d", &a);
    printf("enter years strat:");
    scanf("%d", &b);

    for (int i = a; i <=b; i++)
    {
        if(i%4==0)
        {
          fprintf(file,"%d ",i);
        }
    }
    

    return 0;
}