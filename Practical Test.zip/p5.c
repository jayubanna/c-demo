#include <stdio.h>
int main()
{
    int a, b, c;

    printf("enter the 1 number:");
    scanf("%d", &a);
    printf("enter the 2 number:");
    scanf("%d", &b);
    printf("enter the 3 number:");
    scanf("%d", &c);

    a>b && a>c?printf("this is 1 number maximum.."):b>c?printf("this is 2 number maximum.."):printf("this is 3 number maximum..");
    return 0;
}