#include<stdio.h>
int main()
{
    float pi=3.14;
    int rid;
  

    printf("enter the radius=");
    scanf("%d",&rid);

    printf("Program to find the area of a circle:%0.2f",pi*rid*rid);

    return 0; 
}