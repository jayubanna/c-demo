#include<stdio.h>
int main()
{
    int b,h,area;

    printf("enter the b=");
    scanf("%d",&b);
    printf("enter the h=");
    scanf("%d",&h);    

    area=b*h/2;

    printf("Program to find the area of a triangle:%d",area);

    return 0;

} 